import itertools
import json
from turtle import st

def getAllCombo(list):
    result = []
    if len(list) > 5:
        print(f"exceed max number of tags {len(list)}, using the first 5...")
        list = list[:5]
    
    for L in range(1, len(list)+1):
        for subset in itertools.combinations(list, L):
            result.append(subset)

    return result

f = open('character.json')
data = json.load(f)
operators = data.values()
f.close()

starToTag = {6: 11, 5: 14, 2: 17}

for combo in getAllCombo([7, 25, 26, 11, 9]):
    print(combo)
    publicRecruitmentOperators = filter(lambda x: bool(x['recruitment']), operators)
    for operator in publicRecruitmentOperators:
        tagset = operator["tags"] + [operator['profession']] + [operator['position']]
        if operator['star'] in starToTag:
            tagset += [starToTag[operator['star']]]
        if set(combo).issubset(tagset):
            print(operator["appellation"])
